﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class WriteCsv : MonoBehaviour {

	// ファイル名(Unity側から設定)
	public string fileName;
	public string directory = "Score";

	// 譜面データ書き出し
	public void WriteScore(string txt){
		StreamWriter sw;
		// 格納ディレクトリ+ファイル名定義
		FileInfo fi = new FileInfo(Application.dataPath + "/" + directory + "/" + fileName + ".csv");

		// 上書き
		sw = fi.AppendText();
		sw.WriteLine(txt);

		// 解放＆終了
		sw.Flush();
		sw.Close();
	}
}
