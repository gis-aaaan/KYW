﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundStart : MonoBehaviour {

	private AudioSource _audiosource;
	private WriteCsv _writecsv;
	private float _gametimer = 0;
	private bool _isPlaying = false;

	public GameObject startButton;

	// Use this for initialization
	void Start () {
		// コンポーネント接続
		_audiosource = GameObject.Find("GameMusic").GetComponent<AudioSource>();
		_writecsv = GameObject.Find("WriteCsv").GetComponent<WriteCsv>();
	}
	
	// Update is called once per frame
	void Update () {
		// ボタンを押すと連動
		if(_isPlaying){
			DetectKey();
		}
	}

	public void StartMusic(){
		// ボタンと連動して音楽再生
		startButton.SetActive(false); //ボタンを押したら非表示
		_audiosource.Play();
		_gametimer = Time.time;	// 時間取得
		// ボタンを押したら入力可能
		_isPlaying = true;
	}

	// 入力でcsv書き込み
	private void DetectKey(){
		// 一旦スペースキーのみ
		if(Input.GetKeyDown(KeyCode.Space)){
			// ノーツ書き出し。将来的にサブパラメータを書き込めるようカプセル化。
			WriteNote();
		}
	}

	// ノーツ書き出し
	// 現状は時間と複数個の予備パラメータ定義のみ
	// 糞センスが無いからそのうち変える
	private void WriteNote(){
		Debug.Log(GetTiming());
		_writecsv.WriteScore(GetTiming().ToString() + "," + "0" + "," + "0" + "," + "0" + "," + "0");
	}

	private void WriteNote(int num1){
		Debug.Log(GetTiming());
		_writecsv.WriteScore(GetTiming().ToString() + "," + num1 + "," + "0" + "," + "0" + "," + "0");
	}

	private void WriteNote(int num1, int num2){
		Debug.Log(GetTiming());
		_writecsv.WriteScore(GetTiming().ToString() + "," + num1 + "," + num2 + "," + "0" + "," + "0");
	}

	private void WriteNote(int num1, int num2, int num3){
		Debug.Log(GetTiming());
		_writecsv.WriteScore(GetTiming().ToString() + "," + num1 + "," + num2 + "," + num3 + "," + "0");
	}

	private void WriteNote(int num1, int num2, int num3, int num4){
		Debug.Log(GetTiming());
		_writecsv.WriteScore(GetTiming().ToString() + "," + num1 + "," + num2 + "," + num3 + "," + num4);
	}

	// 経過時間を表示
	private float GetTiming(){
		return Time.time - _gametimer;
	}
}
